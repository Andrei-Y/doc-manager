import bpy

bl_info = {
    "name": "Calc",
    "author": "Andrei Yakovlev+LM Qwen",
    "version": (1, 0),
    "blender": (4, 3, 2),
    "location" : "View3D",
    "warning" : "",
    "category" : "Generic"
}

class CalculatorOperator(bpy.types.Operator):
    bl_idname = "object.calculator_operator"
    bl_label = "Calculator Operator"

    def execute(self, context):
        return {'FINISHED'}

class CalculatorPanel(bpy.types.Panel):
    bl_idname = "OBJECT_PT_calculator_panel"
    bl_label = "3D Calculator"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Calc'

    def draw(self, context):
        layout = self.layout

        scene = context.scene
        col = layout.column()

        # Поля ввода первого и второго аргументов
        row = col.row()
        row.label(text="First Argument:")
        row.prop(scene, "calculator_first_arg", text="")

        row = col.row()
        row.label(text="Second Argument:")
        row.prop(scene, "calculator_second_arg", text="")

        # Кнопки операций
        row = col.row(align=True)
        row.operator("object.calculator_add", text="+")
        row.operator("object.calculator_subtract", text="-")
        row.operator("object.calculator_multiply", text="*")
        row.operator("object.calculator_divide", text="/")

        # Дополнительные операции
        row = col.row(align=True)
        row.operator("object.calculator_square", text="x^2")
        row.operator("object.calculator_sqrt", text="√")

        # Поле вывода результата
        row = col.row()
        row.label(text="Result:")
        row.prop(scene, "calculator_result", text="", slider=False)

        # Кнопки копирования результата
        row = col.row(align=True)
        row.operator("object.calculator_copy_to_first", text="Copy to First")
        row.operator("object.calculator_copy_to_second", text="Copy to Second")
        row.operator("object.calculator_copy_result", text="Copy Result")

class CalculatorAddOperator(bpy.types.Operator):
    bl_idname = "object.calculator_add"
    bl_label = "Add"

    def execute(self, context):
        scene = context.scene
        scene.calculator_result = scene.calculator_first_arg + scene.calculator_second_arg
        return {'FINISHED'}

class CalculatorSubtractOperator(bpy.types.Operator):
    bl_idname = "object.calculator_subtract"
    bl_label = "Subtract"

    def execute(self, context):
        scene = context.scene
        scene.calculator_result = scene.calculator_first_arg - scene.calculator_second_arg
        return {'FINISHED'}

class CalculatorMultiplyOperator(bpy.types.Operator):
    bl_idname = "object.calculator_multiply"
    bl_label = "Multiply"

    def execute(self, context):
        scene = context.scene
        scene.calculator_result = scene.calculator_first_arg * scene.calculator_second_arg
        return {'FINISHED'}

class CalculatorDivideOperator(bpy.types.Operator):
    bl_idname = "object.calculator_divide"
    bl_label = "Divide"

    def execute(self, context):
        scene = context.scene
        if scene.calculator_second_arg != 0:
            scene.calculator_result = scene.calculator_first_arg / scene.calculator_second_arg
        else:
            self.report({'ERROR'}, 'Division by zero!')
        return {'FINISHED'}

class CalculatorSquareOperator(bpy.types.Operator):
    bl_idname = "object.calculator_square"
    bl_label = "Square"

    def execute(self, context):
        scene = context.scene
        scene.calculator_result = scene.calculator_first_arg ** 2
        return {'FINISHED'}

class CalculatorSqrtOperator(bpy.types.Operator):
    bl_idname = "object.calculator_sqrt"
    bl_label = "Square Root"

    def execute(self, context):
        import math
        scene = context.scene
        if scene.calculator_first_arg >= 0:
            scene.calculator_result = math.sqrt(scene.calculator_first_arg)
        else:
            self.report({'ERROR'}, 'Cannot take the square root of a negative number!')
        return {'FINISHED'}

class CalculatorCopyToFirstOperator(bpy.types.Operator):
    bl_idname = "object.calculator_copy_to_first"
    bl_label = "Copy to First"

    def execute(self, context):
        scene = context.scene
        scene.calculator_first_arg = scene.calculator_result
        return {'FINISHED'}

class CalculatorCopyToSecondOperator(bpy.types.Operator):
    bl_idname = "object.calculator_copy_to_second"
    bl_label = "Copy to Second"

    def execute(self, context):
        scene = context.scene
        scene.calculator_second_arg = scene.calculator_result
        return {'FINISHED'}

class CalculatorCopyResultOperator(bpy.types.Operator):
    bl_idname = "object.calculator_copy_result"
    bl_label = "Copy Result"

    def execute(self, context):
        import bpy
        context.window_manager.clipboard = str(context.scene.calculator_result)
        self.report({'INFO'}, 'Result copied to clipboard')
        return {'FINISHED'}

def register():
    bpy.utils.register_class(CalculatorOperator)
    bpy.utils.register_class(CalculatorPanel)
    bpy.utils.register_class(CalculatorAddOperator)
    bpy.utils.register_class(CalculatorSubtractOperator)
    bpy.utils.register_class(CalculatorMultiplyOperator)
    bpy.utils.register_class(CalculatorDivideOperator)
    bpy.utils.register_class(CalculatorSquareOperator)
    bpy.utils.register_class(CalculatorSqrtOperator)
    bpy.utils.register_class(CalculatorCopyToFirstOperator)
    bpy.utils.register_class(CalculatorCopyToSecondOperator)
    bpy.utils.register_class(CalculatorCopyResultOperator)

    # Добавляем свойства для хранения аргументов и результата
    bpy.types.Scene.calculator_first_arg = bpy.props.FloatProperty(name="First Argument", default=0.0)
    bpy.types.Scene.calculator_second_arg = bpy.props.FloatProperty(name="Second Argument", default=0.0)
    bpy.types.Scene.calculator_result = bpy.props.FloatProperty(name="Result", default=0.0, options={'HIDDEN'})

def unregister():
    del bpy.types.Scene.calculator_first_arg
    del bpy.types.Scene.calculator_second_arg
    del bpy.types.Scene.calculator_result

    bpy.utils.unregister_class(CalculatorOperator)
    bpy.utils.unregister_class(CalculatorPanel)
    bpy.utils.unregister_class(CalculatorAddOperator)
    bpy.utils.unregister_class(CalculatorSubtractOperator)
    bpy.utils.unregister_class(CalculatorMultiplyOperator)
    bpy.utils.unregister_class(CalculatorDivideOperator)
    bpy.utils.unregister_class(CalculatorSquareOperator)
    bpy.utils.unregister_class(CalculatorSqrtOperator)
    bpy.utils.unregister_class(CalculatorCopyToFirstOperator)
    bpy.utils.unregister_class(CalculatorCopyToSecondOperator)
    bpy.utils.unregister_class(CalculatorCopyResultOperator)

if __name__ == "__main__":
    register()

